# 🤖 AI Daily News - AI每日动态报送系统

<div align="center">

![AI Daily News](https://img.shields.io/badge/AI-Daily%20News-6366f1?style=for-the-badge&logo=robot&logoColor=white)
![Python](https://img.shields.io/badge/Python-3.11+-3776ab?style=for-the-badge&logo=python&logoColor=white)
![GitHub Actions](https://img.shields.io/badge/GitHub-Actions-2088ff?style=for-the-badge&logo=github-actions&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)

**每天16:00自动采集100+条原始信息，智能筛选5-20条最重要动态**

[🌐 在线看板](#) | [📖 使用文档](#使用说明) | [🚀 快速开始](#快速开始)

</div>

---

## 🎯 系统特性

### 📡 50+权威新闻源
| 类型 | 来源示例 |
|------|----------|
| **顶级财经媒体** | 华尔街日报、Bloomberg、Reuters、Financial Times |
| **顶级科技媒体** | TechCrunch、The Verge、Wired、VentureBeat |
| **学术研究机构** | MIT Technology Review、Nature、Science、Stanford HAI |
| **权威智库** | RAND Corporation、Brookings、CSIS |
| **政府机构** | White House、EU AI Policy、US Commerce Dept |
| **AI巨头官方** | OpenAI、Google DeepMind、Anthropic、Meta AI、NVIDIA |
| **国内媒体** | 机器之心、量子位、36氪、新智元 |

### 🧠 智能影响力评估模型
系统内置影响力评估算法，自动识别和优先排序：
- 🔴 **重大政策法规**: 行政令、AI法案、制裁禁令、出口管制
- 🟠 **重大产品发布**: GPT-5、Gemini 3、Claude 4、Blackwell等旗舰产品
- 🟡 **重大学术突破**: SOTA性能、Nature/Science论文、图灵奖
- 🟢 **重大商业动态**: 十亿级融资、重大并购、战略合作
- 🔵 **安全与伦理**: AI安全事件、监管动态

### 📊 输出规格
| 指标 | 规格 |
|------|------|
| 原始采集 | 100+ 条/天 |
| 国内精选 | 5-20 条/天 |
| 国际精选 | 5-20 条/天 |
| 重要性等级 | 高/中/低 |
| 影响力评分 | 0-100分 |

---

## 🏗️ 系统架构

```
┌────────────────────────────────────────────────────────────────────┐
│                    AI Daily News System v2.0                        │
├────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐                                                │
│  │ 📡 多源采集模块  │  50+新闻源并行采集                             │
│  │   collector.py  │  → RSS/Web/API                                │
│  └────────┬────────┘                                                │
│           │ 100+条原始信息                                          │
│           v                                                         │
│  ┌─────────────────┐                                                │
│  │ 🎯 影响力评估   │  关键词权重 + 来源权重                          │
│  │  ImpactScorer   │  → 政策/产品/学术/商业/安全                    │
│  └────────┬────────┘                                                │
│           │ 排序后的候选新闻                                         │
│           v                                                         │
│  ┌─────────────────┐                                                │
│  │ 🤖 LLM智能分析  │  GPT-4/Claude深度分析                          │
│  │  processor.py   │  → 摘要生成 + 重要性判断 + 标签提取            │
│  └────────┬────────┘                                                │
│           │ 5-20条精选新闻                                          │
│           v                                                         │
│  ┌─────────────────┐    ┌─────────────────┐                        │
│  │ 💾 数据存储     │    │ 🌐 可视化看板    │                        │
│  │  CSV + JSON     │    │  Web Dashboard  │                        │
│  └─────────────────┘    └─────────────────┘                        │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │         ⏰ GitHub Actions 自动化 (每天北京时间16:00)          │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└────────────────────────────────────────────────────────────────────┘
```

---

## 📁 项目结构

```
ai-daily-news/
├── 📂 src/                     # 源代码
│   ├── __init__.py
│   ├── collector.py            # 多源采集模块 (50+源)
│   ├── processor.py            # 影响力评估 + LLM处理
│   ├── storage.py              # 数据存储模块
│   └── main.py                 # 主程序入口
├── 📂 data/                    # 数据存储
│   ├── news.csv                # 历史新闻CSV (含影响力评分)
│   ├── index.json              # 索引文件
│   └── 📂 daily/               # 每日JSON报告
│       └── YYYY-MM-DD.json
├── 📂 web/                     # 可视化看板
│   ├── index.html
│   ├── 📂 css/
│   │   └── style.css
│   └── 📂 js/
│       └── app.js
├── 📂 .github/workflows/       # GitHub Actions
│   └── daily-news.yml
├── config.py                   # 配置文件 (新闻源+权重)
├── requirements.txt            # Python依赖
└── README.md                   # 项目文档
```

---

## 🚀 快速开始

### 1️⃣ 克隆仓库

```bash
git clone https://github.com/augzhong-wq/AI-daily-news-.git
cd AI-daily-news-
```

### 2️⃣ 安装依赖

```bash
pip install -r requirements.txt
```

### 3️⃣ 配置环境变量

创建 `.env` 文件启用LLM智能分析（可选但推荐）：

```env
# OpenAI API配置
OPENAI_API_KEY=your_api_key_here
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini
```

### 4️⃣ 运行程序

```bash
# 正常运行（采集真实新闻）
python src/main.py

# 演示模式（使用示例数据）
python src/main.py --demo
```

### 5️⃣ 查看结果

- **文本报告**: `data/daily/YYYY-MM-DD_report.txt`
- **JSON数据**: `data/daily/YYYY-MM-DD.json`
- **CSV汇总**: `data/news.csv`
- **Web看板**: 打开 `web/index.html`

---

## ⚙️ 配置说明

### 影响力评估权重

编辑 `config.py` 中的 `IMPACT_KEYWORDS` 调整权重：

```python
IMPACT_KEYWORDS = {
    "policy_high": {
        "weight": 100,  # 政策法规最高权重
        "keywords": ["executive order", "sanctions", "制裁", "行政令"...]
    },
    "product_high": {
        "weight": 90,   # 重大产品发布
        "keywords": ["GPT-5", "Gemini 3", "发布", "opens"...]
    },
    "academic_high": {
        "weight": 85,   # 学术突破
        "keywords": ["breakthrough", "SOTA", "Nobel", "突破"...]
    },
    # ...
}
```

### 来源权重加成

```python
SOURCE_WEIGHTS = {
    "tier1": {
        "multiplier": 1.5,  # 顶级来源 1.5倍加成
        "sources": ["华尔街日报WSJ Tech", "Bloomberg", "Nature AI"...]
    },
    "tier2": {
        "multiplier": 1.3,  # 高级来源 1.3倍加成
        "sources": ["TechCrunch AI", "The Verge AI"...]
    }
}
```

---

## 📊 输出示例

```
======================================================================
AI每日动态 - 2025-12-10
生成时间: 2025-12-10 16:00:00
数据来源: 从 113 条原始信息中精选
======================================================================

【国内动态】
--------------------------------------------------
1、🔥 12月10日消息，国务院正式发布《人工智能产业高质量发展行动计划》，
   提出到2027年我国人工智能核心产业规模超过万亿元...
   📋 入选理由: 国家级重大政策，影响全行业发展方向
   📰 来源: 中国政府网 | 🔗 https://www.gov.cn/
   🏷️ 标签: 政策, 国务院, 产业规划

2、🔥 12月10日消息，智谱AI正式发布新一代基座大模型GLM-5...
   📋 入选理由: 国产大模型重大突破，性能对标国际顶级水平
   ...

【国际动态】
--------------------------------------------------
1、🔥 12月10日消息，美国商务部发布更新的半导体出口管制规则...
   📋 入选理由: 重大政策变化，影响全球AI产业供应链
   ...

2、🔥 12月10日消息，OpenAI正式发布GPT-5大语言模型...
   📋 入选理由: 旗舰产品发布，定义AI能力新标杆
   ...

======================================================================
📊 今日总结: 今日从113条原始信息中精选出10条国内动态和12条国际动态，
   其中12条为高重要性。重点关注：国务院发布AI产业规划；
   美国更新芯片出口管制；OpenAI发布GPT-5。
======================================================================
```

---

## 🔄 GitHub Actions 自动化

### 配置 Secrets

在仓库的 `Settings > Secrets and variables > Actions` 中添加：

| Secret Name | Description | Required |
|-------------|-------------|----------|
| `OPENAI_API_KEY` | OpenAI API密钥 | 推荐 |
| `OPENAI_BASE_URL` | API基础URL | 可选 |
| `OPENAI_MODEL` | 使用的模型 | 可选 |

### 自动运行时间

- **每天北京时间 16:00** 自动执行
- 支持手动触发（可选演示模式）
- 自动提交更新到仓库
- 可选部署到 GitHub Pages

---

## 🌐 GitHub Pages 部署

1. 在仓库 `Settings > Pages` 中启用
2. 选择 `GitHub Actions` 作为部署源
3. 访问: `https://your-username.github.io/AI-daily-news-/`

---

## 📝 开发计划

- [x] 50+新闻源采集
- [x] 影响力评估模型
- [x] LLM智能分析
- [x] 可视化看板
- [x] GitHub Actions自动化
- [ ] 邮件/微信推送通知
- [ ] 自定义关键词监控
- [ ] 新闻情感分析
- [ ] AI趋势预测
- [ ] 多语言支持

---

## 🤝 贡献指南

欢迎提交 Issue 和 Pull Request！

1. Fork 本仓库
2. 创建特性分支：`git checkout -b feature/AmazingFeature`
3. 提交更改：`git commit -m 'Add some AmazingFeature'`
4. 推送到分支：`git push origin feature/AmazingFeature`
5. 提交 Pull Request

---

## 📄 开源协议

本项目采用 [MIT License](LICENSE) 开源协议。

---

<div align="center">

**⭐ 如果这个项目对你有帮助，请给个Star支持一下！**

Made with ❤️ for AI Industry Insights

</div>

"""
AI Daily News System
每日AI动态报送系统
"""
__version__ = "1.0.0"
